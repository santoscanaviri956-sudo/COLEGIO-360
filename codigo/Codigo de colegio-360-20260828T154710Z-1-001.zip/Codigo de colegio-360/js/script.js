const chatContainer = document.getElementById('assistant-container');
const chatBtn = document.getElementById('chat-btn');
const chatWindow = document.getElementById('chat-window');

let isDragging = false;
let hasMoved = false;
let offsetX;
let offsetY;
let startX;
let startY;

chatBtn.addEventListener('pointerdown', (event) => {
  event.preventDefault();
  isDragging = true;
  hasMoved = false;
  startX = event.clientX;
  startY = event.clientY;

  const containerRect = chatContainer.getBoundingClientRect();
  offsetX = event.clientX - containerRect.left;
  offsetY = event.clientY - containerRect.top;
  chatBtn.setPointerCapture(event.pointerId);
  chatBtn.style.cursor = 'grabbing';
});

chatBtn.addEventListener('pointermove', (event) => {
  if (!isDragging) return;
  if (Math.abs(event.clientX - startX) > 5 || Math.abs(event.clientY - startY) > 5) hasMoved = true;

  const newLeft = event.clientX - offsetX;
  const newTop = event.clientY - offsetY;
  const maxLeft = window.innerWidth - chatContainer.offsetWidth;
  const maxTop = window.innerHeight - chatContainer.offsetHeight;

  chatContainer.style.left = `${Math.max(0, Math.min(newLeft, maxLeft))}px`;
  chatContainer.style.top = `${Math.max(0, Math.min(newTop, maxTop))}px`;
  chatContainer.style.bottom = 'auto';
  chatContainer.style.right = 'auto';
});

chatBtn.addEventListener('pointerup', () => {
  if (!isDragging) return;
  isDragging = false;
  chatBtn.style.cursor = 'grab';
  if (!hasMoved) toggleChat();
});

chatBtn.addEventListener('pointercancel', () => {
  isDragging = false;
  chatBtn.style.cursor = 'grab';
});

function toggleChat() {
  chatWindow.style.display = chatWindow.style.display === 'flex' ? 'none' : 'flex';
}

const actionStatus = document.getElementById('action-status');
const schoolLocations = cabaSecondarySchools;

const schoolMap = L.map('map');
const schoolMarkers = [];
const schoolGrid = document.getElementById('school-grid');
const directoryCount = document.getElementById('directory-count');
const detailedSchoolGrid = document.getElementById('detailed-school-grid');
const schoolImages = [
  'https://images.unsplash.com/photo-1562774053-701939374585?auto=format&fit=crop&w=700&q=80',
  'https://images.unsplash.com/photo-1580582932707-520aed937b7b?auto=format&fit=crop&w=700&q=80',
  'https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=700&q=80',
  'https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=700&q=80',
  'https://images.unsplash.com/photo-1497486751825-1233686d5d80?auto=format&fit=crop&w=700&q=80',
  'https://images.unsplash.com/photo-1523050854058-8df90110c9f1?auto=format&fit=crop&w=700&q=80'
];

function renderSchoolDirectory(searchTerm = '') {
  const normalizedSearch = searchTerm.trim().toLowerCase();
  const visibleSchools = schoolLocations.filter(school => school.name.toLowerCase().includes(normalizedSearch));
  schoolGrid.innerHTML = visibleSchools.slice(0, 56).map((school, index) => `
    <article class="school-card">
      <div class="school-image-wrap"><img src="${schoolImages[index % schoolImages.length]}" alt="Edificio y espacio educativo" loading="lazy"><span class="school-image-label"><i class="fa-solid fa-camera"></i> Vista institucional</span></div>
      <div class="school-card-top">
        <h3>${school.name}</h3>
        <span class="school-card-type">${school.name.includes('Técnica') ? 'Técnica' : 'Secundaria'}</span>
      </div>
      <div class="school-rating"><div><strong>★ ${(4.6 + (index % 4) * .1).toFixed(1)}</strong><span>Excelente</span></div><small>${127 + index * 18} opiniones</small></div>
      <div class="rating-details"><span>📚 Educación <b>${(4.7 + (index % 3) * .1).toFixed(1)}</b></span><span>🏫 Instalaciones <b>${(4.6 + (index % 4) * .1).toFixed(1)}</b></span><span>👨‍🏫 Docentes <b>${(4.7 + (index % 2) * .1).toFixed(1)}</b></span></div>
      <p><i class="fa-solid fa-location-dot"></i> Ciudad Autónoma de Buenos Aires</p>
      <button type="button" data-school-index="${schoolLocations.indexOf(school)}">Ver en el mapa <i class="fa-solid fa-arrow-right"></i></button>
    </article>`).join('');
  schoolGrid.querySelectorAll('[data-school-index]').forEach(button => {
    const card = button.closest('.school-card');
    const schoolIndex = Number(button.dataset.schoolIndex);
    card.addEventListener('mouseenter', () => {
      card.classList.add('is-highlighted');
      schoolMarkers[schoolIndex]?.setOpacity(1).setZIndexOffset(1000);
    });
    card.addEventListener('mouseleave', () => {
      card.classList.remove('is-highlighted');
      schoolMarkers[schoolIndex]?.setZIndexOffset(0);
    });
  });
  directoryCount.textContent = `${visibleSchools.length} ${visibleSchools.length === 1 ? 'institución' : 'instituciones'}`;
}

function renderDetailedDirectory(searchTerm = '') {
  const normalizedSearch = searchTerm.trim().toLowerCase();
  const visibleSchools = schoolLocations.filter(school => school.name.toLowerCase().includes(normalizedSearch));
  detailedSchoolGrid.innerHTML = visibleSchools.slice(0, 6).map((school, index) => `
    <article class="detailed-school-card">
      <div class="detailed-school-image"><img src="${schoolImages[index]}" alt="Imagen de referencia de ${school.name}" loading="lazy"></div>
      <div class="detailed-school-content">
        <div class="detailed-title-row"><h3><i class="fa-solid fa-school"></i> ${school.name}</h3><span class="rating-main">★ ${(4.6 + (index % 4) * .1).toFixed(1)}<small>/5</small></span></div>
        <div class="school-meta"><span><i class="fa-solid fa-location-dot"></i> Distancia: <b>${(1.2 + index * .7).toFixed(1)} km</b></span><span><i class="fa-solid fa-graduation-cap"></i> Primaria · Secundaria</span><span><i class="fa-solid fa-wallet"></i> Desde <b>$${(120 + index * 15).toLocaleString('es-AR')}.000</b></span></div>
        <div class="school-method"><i class="fa-solid fa-brain"></i> Metodología: <b>${index % 2 ? 'Constructivista' : 'Montessori'}</b></div>
        <div class="service-tags"><span>🚌 Transporte</span><span>🍽️ Comedor</span><span>🤖 Robótica</span></div>
        <div class="detailed-actions"><button type="button" class="save-school" data-action="save"><i class="fa-regular fa-heart"></i> Guardar</button><button type="button" data-action="compare"><i class="fa-solid fa-scale-balanced"></i> Comparar</button><button type="button" class="view-school" data-action="view" data-school-index="${schoolLocations.indexOf(school)}">Ver colegio <i class="fa-solid fa-arrow-right"></i></button></div>
      </div>
    </article>`).join('');
}

renderSchoolDirectory();
renderDetailedDirectory();

schoolGrid.addEventListener('click', event => {
  const button = event.target.closest('[data-school-index]');
  if (!button) return;
  const schoolIndex = Number(button.dataset.schoolIndex);
  const school = schoolLocations[schoolIndex];
  schoolMap.setView(school.position, 14);
  schoolMarkers[schoolIndex].openPopup();
  showAction(`${school.name}: ${school.detail}.`);
});

detailedSchoolGrid.addEventListener('click', event => {
  const button = event.target.closest('[data-action]');
  if (!button) return;
  if (button.dataset.action === 'view') {
    const schoolIndex = Number(button.dataset.schoolIndex);
    schoolMap.setView(schoolLocations[schoolIndex].position, 14);
    showAction(`${schoolLocations[schoolIndex].name}: ${schoolLocations[schoolIndex].detail}.`);
  }
  if (button.dataset.action === 'save') {
    button.classList.toggle('is-saved');
    button.innerHTML = button.classList.contains('is-saved') ? '<i class="fa-solid fa-heart"></i> Guardado' : '<i class="fa-regular fa-heart"></i> Guardar';
  }
  if (button.dataset.action === 'compare') showAction('Colegio agregado a la comparación.');
});

L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
  attribution: '&copy; OpenStreetMap contributors'
}).addTo(schoolMap);

schoolLocations.forEach(school => {
  const marker = L.marker(school.position, { opacity: 0 }).addTo(schoolMap)
    .bindPopup(`<strong>${school.name}</strong><br>${school.detail}`)
    .on('click', () => {
      actionStatus.textContent = `${school.name}: ${school.detail}.`;
    });
  schoolMarkers.push(marker);
});

async function geocodeSchools() {
  const resolvedPositions = [];
  for (let index = 0; index < schoolLocations.length; index += 1) {
    const school = schoolLocations[index];
    try {
      const query = encodeURIComponent(`${school.name}, Ciudad Autónoma de Buenos Aires`);
      const response = await fetch(`https://photon.komoot.io/api/?limit=1&q=${query}`);
      const data = await response.json();
      const coordinates = data.features?.[0]?.geometry?.coordinates;
      if (coordinates?.length === 2) {
        school.position = [coordinates[1], coordinates[0]];
        schoolMarkers[index].setLatLng(school.position);
        schoolMarkers[index].setOpacity(1);
        schoolMarkers[index].bindTooltip(school.name, {
          permanent: true,
          direction: 'top',
          offset: [0, -10]
        });
        resolvedPositions.push(school.position);
        schoolMap.fitBounds(L.latLngBounds(resolvedPositions), {
          padding: [30, 30]
        });
      }
    } catch (error) {
    }
    await new Promise(resolve => setTimeout(resolve, 350));
  }
}

geocodeSchools();

function showAction(message) {
  actionStatus.textContent = message;
}

document.getElementById('favorites-btn').addEventListener('click', () => showAction('Todavía no tienes colegios favoritos.'));
document.getElementById('compare-btn').addEventListener('click', () => showAction('Selecciona colegios desde sus marcadores para compararlos.'));
document.getElementById('pedagogical-match-btn').addEventListener('click', () => showAction('El Match Pedagógico IA estará disponible al completar tus preferencias.'));
document.getElementById('general-match-btn').addEventListener('click', () => showAction('El Matcher General está listo para recibir tus criterios de búsqueda.'));
document.getElementById('login-btn').addEventListener('click', () => showAction('Formulario de inicio de sesión próximamente.'));
document.getElementById('register-btn').addEventListener('click', () => showAction('Formulario de registro próximamente.'));

function locateUser() {
  if (!navigator.geolocation) {
    showAction('La geolocalización no está disponible en este navegador.');
    return;
  }
  showAction('Solicitando tu ubicación...');
  navigator.geolocation.getCurrentPosition(
    position => {
      const userPosition = [position.coords.latitude, position.coords.longitude];
      schoolMap.setView(userPosition, 14);
      L.marker(userPosition).addTo(schoolMap).bindPopup('Tu ubicación').openPopup();
      showAction('Mapa centrado en tu ubicación.');
    },
    () => showAction('No se pudo acceder a tu ubicación. Revisa el permiso del navegador.')
  );
}

document.getElementById('nearby-btn').addEventListener('click', locateUser);
document.getElementById('gps-btn').addEventListener('click', locateUser);

const filterSearch = document.getElementById('filter-search');
const heroSearch = document.getElementById('hero-search');
const filterLevel = document.getElementById('filter-level');
const filterMethodology = document.getElementById('filter-methodology');
const filterOrientation = document.getElementById('filter-orientation');
const filterEnrollment = document.getElementById('filter-enrollment');
const filterRating = document.getElementById('filter-rating');
const filterDistance = document.getElementById('filter-distance');
const filterScholarships = document.getElementById('filter-scholarships');
const filterFacilities = [...document.querySelectorAll('.checkbox-item input')];
const priceFilter = document.getElementById('price-filter');
const priceValue = document.getElementById('price-val');
const mapLabel = document.getElementById('action-status');
const defaultMapLabel = mapLabel.textContent;
const activeFilterCount = document.getElementById('active-filter-count');

heroSearch.addEventListener('input', () => {
  filterSearch.value = heroSearch.value;
  applyFilters();
});

document.getElementById('search-clear').addEventListener('click', () => {
  heroSearch.value = '';
  filterSearch.value = '';
  applyFilters();
  heroSearch.focus();
});

document.querySelectorAll('[data-quick-filter]').forEach(button => {
  button.addEventListener('click', () => {
    document.querySelectorAll('[data-quick-filter]').forEach(item => item.classList.remove('is-active'));
    button.classList.add('is-active');
    const filterType = button.dataset.quickFilter;
    if (filterType === 'nearby') locateUser();
    if (filterType === 'price') {
      priceFilter.value = 100000;
      priceValue.textContent = '$100.000';
      applyFilters();
    }
    if (filterType === 'bilingual') {
      filterOrientation.value = 'Bilingüe';
      applyFilters();
    }
    if (filterType === 'top') showAction('Mostrando instituciones destacadas para tu búsqueda.');
  });
});

function applyFilters() {
  const activeFilters = [filterSearch.value.trim(), filterLevel.selectedIndex, filterMethodology.selectedIndex,
    filterOrientation.selectedIndex, filterEnrollment.selectedIndex, filterScholarships.selectedIndex,
    filterRating.selectedIndex, filterDistance.selectedIndex, priceFilter.value < priceFilter.max,
    ...filterFacilities.map(input => input.checked)].filter(Boolean).length;
  const hasFilters = activeFilters > 0;
  activeFilterCount.textContent = `${activeFilters} ${activeFilters === 1 ? 'filtro activo' : 'filtros activos'}`;
  mapLabel.textContent = hasFilters
    ? 'Filtros aplicados: ajusta la vista del mapa'
    : defaultMapLabel;
  renderSchoolDirectory(filterSearch.value);
  renderDetailedDirectory(filterSearch.value);
}

[filterSearch, filterLevel, filterMethodology, filterOrientation, filterEnrollment, filterScholarships,
  filterRating, filterDistance,
  priceFilter, ...filterFacilities].forEach(control => {
  control.addEventListener('input', applyFilters);
  control.addEventListener('change', applyFilters);
});

priceFilter.addEventListener('input', () => {
  priceValue.textContent = '$' + Number(priceFilter.value).toLocaleString('es-AR');
});

document.getElementById('reset-filters').addEventListener('click', () => {
  filterSearch.value = '';
  heroSearch.value = '';
  filterLevel.selectedIndex = 0;
  filterMethodology.selectedIndex = 0;
  filterOrientation.selectedIndex = 0;
  filterEnrollment.selectedIndex = 0;
  filterScholarships.selectedIndex = 0;
  filterRating.selectedIndex = 0;
  filterDistance.selectedIndex = 0;
  priceFilter.value = 250000;
  priceValue.textContent = '$250.000';
  filterFacilities.forEach(input => input.checked = false);
  document.querySelectorAll('[data-quick-filter]').forEach(item => item.classList.remove('is-active'));
  applyFilters();
});

document.getElementById('apply-filters').addEventListener('click', () => {
  showAction(`${activeFilterCount.textContent}. Resultados actualizados.`);
});

const chatInput = document.getElementById('chat-input');
const chatBody = document.querySelector('.chat-body');

function sendChatMessage() {
  const message = chatInput.value.trim();
  if (!message) return;
  const messageElement = document.createElement('div');
  messageElement.className = 'chat-msg';
  messageElement.textContent = `Recibí tu consulta: ${message}`;
  chatBody.appendChild(messageElement);
  chatInput.value = '';
}

document.getElementById('chat-send').addEventListener('click', sendChatMessage);
chatInput.addEventListener('keydown', event => {
  if (event.key === 'Enter') sendChatMessage();
});
